export const VAPID_PUBLIC_KEY = "__VAPID_PUBLIC_KEY__";
